#include <stdio.h>
#include <stdlib.h>
#include <math.h>

int main(void)
{
	double a=8.733243;
	
	printf("sqrt(%f)=%f\n", a, sqrt(a));
	
	return 0;
}

